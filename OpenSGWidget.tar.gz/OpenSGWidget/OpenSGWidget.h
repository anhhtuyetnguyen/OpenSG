#include <QGLWidget>
#include <QMouseEvent>
#include <QApplication>
#include <OpenSG/OSGConfig.h>
#include <OpenSG/OSGSceneFileHandler.h>
#include <OpenSG/OSGSimpleGeometry.h>
#include <OpenSG/OSGPassiveWindow.h>
#include <OpenSG/OSGSimpleSceneManager.h>

// our widget class will be derived from QGLWidget,
// a widget offering support for plain OpenGL

class OpenSGWidget : public QGLWidget{
public:
	OpenSGWidget( );
	OSG::SimpleSceneManager *getManager(void);

protected:
	// these replace the callback functions
	// you now from the other tutorials
	void initializeGL();
	void resizeGL(int, int);
	void paintGL();
	void mousePressEvent(QMouseEvent *ev);
	void mouseMoveEvent(QMouseEvent *ev);
	void mouseReleaseEvent(QMouseEvent *ev);
	void wheelEvent(QWheelEvent *ev);

	OSG::SimpleSceneManager *mMgr;
	// no GLUT window this time, but a passive one
	OSG::PassiveWindowPtr mPwin;
};

