#include <QApplication>
#include <OpenSG/OSGConfig.h>
#include <OpenSG/OSGNode.h>
#include <QtGui>
#include "OpenSGWidget.h"

OSG_USING_NAMESPACE;

int main( int argc, char **argv ){
	osgInit(argc,argv);

	QApplication application(argc, argv);

	OpenSGWidget *widget = new OpenSGWidget();

	QWidget wdg;
	QHBoxLayout *mainLayout = new QHBoxLayout;
	mainLayout->addWidget(widget);
	wdg.setLayout(mainLayout);

	NodePtr scene;
	scene = makeTorus(.5, 2, 16, 16);

	widget->getManager()->setRoot(scene);
	widget->getManager()->showAll();

	widget->show();

	wdg.show();

	return application.exec();
}

