#include "OpenSGWidget.h"

//constructor
OpenSGWidget::OpenSGWidget( ) : QGLWidget( ){	
	mMgr = new OSG::SimpleSceneManager;
	mPwin = OSG::PassiveWindow::create();
	mMgr->setWindow(mPwin);
}

OSG::SimpleSceneManager *OpenSGWidget::getManager(void){
	return mMgr;
}
 
void OpenSGWidget::initializeGL(){
	mPwin->init();	
}

void OpenSGWidget::resizeGL(int width, int height){
	mMgr->resize(width,height);
}

// this replaces the display function
void OpenSGWidget::paintGL(){
	mMgr->redraw();
}

void OpenSGWidget::mousePressEvent(QMouseEvent *ev){
	OSG::UInt32 button;
	
	// translate the button value from qt to OpenSG
	switch (ev->button()){
		case Qt::LeftButton:  button = OSG::SimpleSceneManager::MouseLeft;   break;
		case Qt::MidButton:   button = OSG::SimpleSceneManager::MouseMiddle; break;
		case Qt::RightButton: button = OSG::SimpleSceneManager::MouseRight;  break;
		default:          return;
	}
	
	//passs the event to the manager object
	mMgr->mouseButtonPress(button, ev->x(), ev->y());
	update();
}

void OpenSGWidget::mouseReleaseEvent(QMouseEvent *ev){
   OSG::UInt32 button;

	switch (ev->button()){
		case Qt::LeftButton:  button = OSG::SimpleSceneManager::MouseLeft;   break;
		case Qt::MidButton:   button = OSG::SimpleSceneManager::MouseMiddle; break;
		case Qt::RightButton: button = OSG::SimpleSceneManager::MouseRight;  break;
		default:          return;
	}
     
   mMgr->mouseButtonRelease(button, ev->x(), ev->y());
   update();
}

void OpenSGWidget::mouseMoveEvent(QMouseEvent *ev){
	mMgr->mouseMove(ev->x(), ev->y());
	update();
}

void OpenSGWidget::wheelEvent(QWheelEvent *ev){
	mMgr->mouseButtonPress(ev->delta() > 0 ? OSG::SimpleSceneManager::MouseUp : OSG::SimpleSceneManager::MouseDown, ev->x(), ev->y());
    
	ev->accept();
	update();
}

